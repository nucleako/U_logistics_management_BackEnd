const { Service } = require('egg');


class UserService extends Service{
    async findAll(){//查询员工逻辑并返回数据
        // const res = this.app.mysql.get('base_role');//获取数据
        // var sql = 'select * from base_role' //query
        var sql = 'base_user'
        const res = await this.app.mysql.select(sql);//获取数据
        return res
    }

    async findUserById(query){//查询员工逻辑并返回数据
        console.log(query);
        const res = await this.app.mysql.get('base_user',query);//获取数据
        return res
    }

    async saveOrUpdateUser(){
        if (data.id) {
            var res = await this.app.mysql.update('base_user',data);//获取数据
        }else{
            var res = await this.app.mysql.insert('base_user',data);//获取数据
        }
        return res;
    }

    async login(data){

        const res = await this.app.mysql.get('base_user',data);//获取数据

        if (!res) {
            return '用户名或密码错误'
        }else{
            // 签发token
            const token = 'Bearer ' + this.app.jwt.sign(
                { username: data.username },    //生成token后、jiexitoken会返回这个信息
                this.app.config.jwt.secret,     //密钥
                { expiresIn: '3600s' }          //有效期
            );
            //token in header
            // Content-Type: application/x-www-form-urlencoded
            // Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImFkbWluMSIsImlhdCI6MTY3Njk4ODI3OSwiZXhwIjoxNjc2OTkxODc5fQ.pXHIGTULremJtkTOFw8SrCeRUmGBjsDCqpjl3BQVcu8
            return token;
        }
    }

}

module.exports = UserService;
