const { Service } = require('egg');


class ListService extends Service{
    async findAll(){//查询员工逻辑并返回数据
        // const res = this.app.mysql.get('base_role');//获取数据
        // var sql = 'select * from base_role' //query
        var sql = 'base_list'
        const res = await this.app.mysql.select(sql);//获取数据
        return res
    }
    async findListById(query){//查询员工逻辑并返回数据
        console.log(query);
        this.ctx.validate({
            name: { type : 'String' }
        })
        const res = await this.app.mysql.get('base_list',query);//获取数据
        return res
    }
    async saveOrUpdateList(data){
        if (data.id) {
            var res = await this.app.mysql.update('base_list',data);//获取数据
        }else{
            var res = await this.app.mysql.insert('base_list',data);//获取数据
        }
        return res;
    }
    async deleteList(data){
        const res={}//= await this.app.mysql.delete('base_list', data);//及其危险、删掉了整个数据库
        console.log(data+'11111');
        return res;
    }
}

module.exports = ListService;
