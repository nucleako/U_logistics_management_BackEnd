'use strict';

const { Controller } = require('egg');

class ClientController extends Controller {

}
module.exports = ClientController;