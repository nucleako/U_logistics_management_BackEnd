'use strict';

const { Controller } = require('egg');

class UserController extends Controller {
  async findAll() {
    const { ctx } = this;//context可以获取请求对象、响应对象
    // ctx.body = 'user config successed';//响应体数据=》自动转json
    // console.log(ctx.request.query);
    const data = await ctx.service.user.findAll();//promise
    // console.log(data);
    ctx.body = {state:200,message:'success',data,time:new Date().getTime()};//响应体数据=》自动转json
  }
  async findUserById(){
    const { ctx } = this;//context可以获取请求对象、响应对象
    const data = await ctx.service.user.findUserById(ctx.query);//promise
    ctx.response.body = {state:200,message:'success',data,time:new Date().getTime()};//响应体数据=》自动转json
  }
}

module.exports = UserController;
