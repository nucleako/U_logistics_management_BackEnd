'use strict';

const { Controller } = require('egg');

/**
 * @Controller UserController:⽤户模块
 */

class UserController extends Controller {

    /**
   * @Router post /user/login
   * @Summary 登录接口
   * @Description 用户名密码
   * @Request body login *body
   */
    async login(){
      const { ctx } = this;
      console.log(ctx.request.body);
      const data = await ctx.service.user.login(ctx.request.body);
      ctx.body =data;
    }  

  /**
   * @Router get /user/findAll
   * @Summary 查询所有用户信息
   * @apikey
   */
  async findAll() {
    const { ctx } = this;//context可以获取请求对象、响应对象
    // ctx.body = 'user config successed';//响应体数据=》自动转json
    // console.log(ctx.request.query);
    const data = await ctx.service.user.findAll();//promise
    // console.log(data);
    ctx.body = {state:200,message:'success',data,time:new Date().getTime()};//响应体数据=》自动转json
  }

  /**
   * @Router get /user/findUserById
   * @Summary 依据某条信息查询
   * @Description 任意信息皆可、仅返回一条内容
   * @apikey
   */
  async findUserById(){
    const { ctx } = this;
    const data = await ctx.service.user.findUserById(ctx.query);//promise
    ctx.response.body = {state:200,message:'success',data,time:new Date().getTime()};//响应体数据=》自动转json
  }

  /**
   * @Router post /user/saveOrUpdateUser
   * @Summary 新增或删除
   * @Description 修改某一项数据
   * @apikey
   */
  async saveOrUpdateUser(){
    const { ctx } = this;//context可以获取请求对象、响应对象
    ctx.validate({
      name: { type : 'string' }
    })
    console.log(ctx.request.body);
    const data = await ctx.service.list.saveOrUpdateList(ctx.request.body);//promise
    ctx.body={state:200,message:'success',data,time:new Date().getTime()};
  }
}

module.exports = UserController;
