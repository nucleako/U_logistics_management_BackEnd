'use strict';

/**
 * @param {Egg.Application} app - egg application
 */
module.exports = app => {
  const { router, controller ,jwt} = app;
  router.get('/', controller.home.index);
  router.post('/user/login', controller.user.login);
  router.get('/user/findAll',jwt, controller.user.findAll);
  router.get('/user/findUserById',jwt, controller.user.findUserById);
  router.get('/list/findAll',jwt, controller.list.findAll);
  router.get('/list/findListById',jwt, controller.list.findListById);
  router.post('/list/saveOrUpdateList',jwt, controller.list.saveOrUpdateList);
  // router.delete('/list/deleteList', controller.list.deleteList);
  
  // router.get('/stock/findAll',jwt, controller.stock.findAll);

  // router.get('/client/findAll',jwt,controller.client.findAll);
};
