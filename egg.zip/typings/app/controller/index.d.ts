// This file is created by egg-ts-helper@1.34.7
// Do not modify this file!!!!!!!!!
/* eslint-disable */

import 'egg';
import ExportClient = require('../../../app/controller/client');
import ExportHome = require('../../../app/controller/home');
import ExportList = require('../../../app/controller/list');
import ExportStock = require('../../../app/controller/stock');
import ExportUser = require('../../../app/controller/user');

declare module 'egg' {
  interface IController {
    client: ExportClient;
    home: ExportHome;
    list: ExportList;
    stock: ExportStock;
    user: ExportUser;
  }
}
